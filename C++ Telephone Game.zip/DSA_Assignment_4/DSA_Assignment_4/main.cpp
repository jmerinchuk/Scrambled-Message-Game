/*******************************************************************
 * Program: Assignment 4
 * Programmer: Jayce Merinchuk
 * Programmer: Vanessa Li
 * Programmer: Haya ElGhalayini
 * Date: March 14, 2019
 * File:   main.cpp
 * Description: This program mimics the telephone or password game.
 * 1. The user enters the number of players in the game from 1-50.
 * 2. A string (sentence) is loaded into the program either by loading
 *    or creating a new one.
 * 3. The user can save the sentence to a file, display the sentence,
 *    delete the sentence, play the game, or exit the program. 
 * 4. Play - The game cycles through each player and rolls a number between
 *    0-100 to check understanding of the message passed.
 * 5. The message can either be: sorted, have a letter deleted, have a letter
 *    added, change a letter, or pass the message successfully.
 * 6. The game ends once all players have passed the message and then 
 *    the final message is displayed.
 * 
 * Sources:
 *  http://www.cplusplus.com/doc/tutorial/files/
 *  For loading from a file into the Linked List.
 * 
 *  http://www.cplusplus.com/doc/tutorial/files/
 *  For saving to a file from a Linked List.
 * 
 *  https://en.cppreference.com/w/cpp/string/byte/strlen
 *  For reading input (from defined in header at top of page)
 * 
 *  http://www.cplusplus.com/reference/cstdlib/rand/
 *  For obtaining a random number
 *  
 *  Haya's Priority Queue program provided a base to draw from for
 *  the while loop and switch menu used in this program.
 * 
 ******************************************************************/

// Libraries for use within the program
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <stdio.h>
#include "LinkedList.h"
using namespace std;

// Global Variables
LinkedList list;
char let;
char sentence[100];
int players;
char letter[] = {'A','B','C','D','E','F','G','H','I','J','K','L','M',
'N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d',
'e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u',
'v','w','x','y','z'};

// Function prototypes
void read_input();
int get_random();
void play_game();
void save_sentence();
void load_sentence();

/*********************************************
 * Method: main
 * Description: Runs the menu of the program.
 ********************************************/
int main(int argc, char** argv) {
    // Choose the psuedo-random set of integers
    srand(3);
    
    // Variables for the program
    int option;
    
    // Ask for a the number of people playing the game.
    cout << "How many people are playing the Telephone Game? (1-50)" << endl;
    cin >> players;
    while (players < 1 || players > 50) {
        cout << "Please enter a number between 1-50" << endl;
        cin >> players;
    }
    
    // Run the program while input is not equal to 4 (exit)
    do { 
        cout 
        << "1.Create new sentence\n"
        << "2.Save sentence\n"
        << "3.Load sentence\n"
        << "4.Display current sentence\n"
        << "5.Delete current sentence\n"
        << "6.Play Game\n"
        << "0.Quit Program\n"
        << "Enter your choice: ";
        cin >> option;

        // Option passed picks the menu option from above.
        switch (option) {
            case 0:
                cout << "Exiting program..." << endl;
                return 0;
            case 1:
                cout << "Creating new sentence..." << endl;
                read_input();
                break;
            case 2:
                cout << "Attempting to save current sentence..." << endl;
                save_sentence();
                break;
            case 3:
                cout << "Attempting to load sentence from file..." << endl;
                load_sentence();
                break;
            case 4:
                cout << "Displaying sentence..." << endl;
                list.display();
                break;
            case 5:
                cout << "Deleting current sentence..." << endl;
                list.delete_all();
                break;
            case 6:
                if (list.check_sentence() == false) {
                    cout << "Please create a sentence first." << endl;
                    cout << "Returning to main menu..." << endl;
                } else {
                    // play the game
                    cout << "\nStarting game with message: ";
                    list.display();
                    play_game();
                }
                break;
            default:
                cout << "Please enter an integer to select a menu option" << endl;
                break;
        }
    } while (option != 0);
    return 0;
}

/*********************************************
 * Method: save_sentence()
 * Description: Saves the current sentence
 * in a text file.
 * O(n)
 ********************************************/
void save_sentence() {
    if (list.check_sentence() == false) {
        cout << "Please create a sentence first." << endl;
        return;
    } else {
        string saying = list.toString();
        ofstream outFile;
        outFile.open("C:\\Netbeans\\Data Structures and Algorithms\\DSA_Assignment_4\\sentence.txt");
        outFile << saying;
        outFile.close();
    }
}

/*********************************************
 * Method: load_sentence()
 * Description: Loads the text file text as
 * the sentence
 * O(n)
 ********************************************/
void load_sentence() {
    if (list.check_sentence() == true) {
        cout << "Please delete the current sentence before loading a new one." << endl;
        return;
    } else {
        ifstream inFile;
        /* Ensure you path this properly before running! */
        inFile.open("C:\\Netbeans\\Data Structures and Algorithms\\DSA_Assignment_4\\sentence.txt");
        if (!inFile) {
            cerr << "Unable to open file sentence.txt\n";
            inFile.close();
            return;
        } else {
            while (inFile >> let) {
                list.insert_last(let);
            }
        }
        inFile.close();
    }
}


/*********************************************
 * Method: read_input()
 * Description: Reads sentence input and 
 * stores in the Linked List.
 ********************************************/
void read_input() {
    cout << "Please enter the sentence for the game." << endl;
    cin >> sentence;

    size_t len = strlen(sentence);
    for (int i = 0; i < len; i++) {
        list.insert_last(sentence[i]);
    }
}

/*********************************************
 * Method: get_random()
 * Description: Returns a random number
 * between 1-list size
 ********************************************/
int get_random(int size) {
    int random = (rand() % size);
    return random;
}

/*********************************************
 * Method: play_game()
 * Description: 
 * 1. Initialize variables 
 * 2. Use for loop to cycle through all players
 * 3. Roll a random number between 0-100 for 
 * chance of node being changed/added/deleted.
 * 4. Roll a random number between 0-list size
 * for passing which node will be changed.
 * 5. Get random letter from array for changing
 * or adding.
 * 6. 
 ********************************************/
void play_game() {
    // Variables
    int roll;
    int list_index;
    int letter_index;
    char character;
    
    // cycle through all players in the game.
    for (int i = 0; i < players; i++) {
        // Roll a random number between 0-100
        roll = get_random(101);
        cout << "you rolled a " << roll << endl;
        list_index = get_random(list.size());
        letter_index = get_random(53);
        character = letter[letter_index];
        
        /*************************************
        * Roll: 0-9  
        * Action: Entire message is being 
        * sorted A-Z
        *************************************/
        if (roll >=0 && roll <= 9) {
            cout << "Sorting message..." << endl;
            list.sort_sentence();
        }
        
        /************************************
        * Roll: 10-29  
        * Action: delete a random letter at index.
        ************************************/
        if (roll >= 10 && roll <= 29) {
            list.delete_random(list_index);
            cout << "Deleted random letter: ";
            list.display();
        }
        
        /************************************
        * Roll: 30-49  
        * Action: Add a random letter at index
        ************************************/
        if (roll >= 30 && roll <= 49) {
            list.insert_random(list_index, character);
            cout << "Added random letter: ";
            list.display();
        }
        
        /************************************
        * Roll: 50-79  
        * Action: Change a random letter.
        ************************************/
        if (roll >= 50 && roll <= 79) {
            list.change_random(list_index, character);
            cout << "Changed random letter: ";
            list.display();
        }
        
        /*****************************************
        * Roll: 80-100  
        * Action: Nothing.
        ****************************************/
        if (roll >= 80 && roll <= 100) {
            cout << "The message was passed successfully." << endl;
            list.display();
        }
    }
    cout << "Game Over!" << endl;
    cout << "The final message is: ";
    list.display(); 
    cout << endl;
}