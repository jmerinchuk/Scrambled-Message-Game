/*******************************************************************
 * Program: Assignment 4
 * Programmer: Jayce Merinchuk
 * Programmer: Vanessa Li
 * Programmer: Haya ElGhalayini
 * Date: March 14, 2019
 * File: LinkedList.h
 * Description: Class for Linked List with various methods for 
 * addressing the linked list in the game.
 * 
 * Sources:
 *  https://www.techiedelight.com/convert-char-array-string-cpp/
 *  For changing character array to string
 * 
 *  Haya's in-class lessons on Linked Lists assisted with creating
 *  some of these methods.
 *  
 *  Haya's in-class lessons on sorting assisted with creating
 *  the selection sort method used in this Class.
 * 
 ******************************************************************/

#ifndef LINKEDLIST_H
#define LINKEDLIST_H

// Libraries for use within the program
#include<iostream>
#include <string>
#include<cstdio>
#include<cstdlib>
#include "Node.h"
using namespace std;

/*********************************************
 * Class: LinkedList
 * Description: Contains all methods that
 * a Linked List can perform with the Nodes.
 ********************************************/
class LinkedList {
private:
    Node * start;
public:
    Node * create_node(char);
    void insert_random(int, char);
    void insert_last(char);
    void change_random(int, char);
    void delete_random(int);
    void delete_all();
    void display();
    string toString();
    int size();
    bool check_sentence();
    void save_sentence();
    void load_sentence();
    void sort_sentence();

    /**************************************
     * Constructor
     *************************************/
    LinkedList() {
        start = NULL;
    }
};

/******************************************
 * Method: create_node()
 * Description: Creates a new Node.
 * O(1)
 *****************************************/
Node *LinkedList::create_node(char value) {
    Node * temp = new Node;
    if (temp == NULL) {
        cout << "Memory cannot be allocated. Exiting Program." << endl;
        return 0;
    } else {
        temp->data = value;
        temp->next = NULL;
        return temp;
    }
}

/******************************************
 * Method: insert_random()
 * Description: Inserts a new node at a 
 * random number in the sentence.
 * O(n)
 *****************************************/
void LinkedList::insert_random(int number, char value) {
    struct Node * temp = create_node(value);
    if (number == 0) {
        temp->next = start;
        start = temp;
    } else {
        Node * previous = NULL;
        Node * current = start;
        int count = 0;
        while (count != number) {
            previous = current;
            current = current->next;
            count++;
        }
        temp->next = current;
        previous->next = temp;
    }
}

/******************************************
 * Method: insert_last()
 * Description: Inserts a new Node at the 
 * last position in the list.
 * O(n)
 *****************************************/
void LinkedList::insert_last(char value) {
    struct Node * temp = create_node(value); 
    if (start == NULL) {
        temp->next = NULL;
        start = temp;
    } else {
        Node * current = start;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = temp;
    }
}

/******************************************
 * Method: change_random()
 * Description: Changes a random Node->data
 * in the list.
 * O(n)
 *****************************************/
void LinkedList::change_random(int number, char letter) {
    Node * current = start;
    int count = 0;
    while (count != number) {
        current = current->next;
        count++;
    }
    current->data = letter;
}

/******************************************
 * Method: delete_random()
 * Description: Deletes a random Node in
 * the list.
 * O(n)
 *****************************************/
void LinkedList::delete_random(int number) {
    Node * previous = NULL;
    Node * current = start;
    int count = 0;
    while (count != number) {
        previous = current;
        current = current->next;
        count++;
    }
    previous->next = current->next;
    delete(current);
}

/******************************************
 * Method: delete_all()
 * Description: Deletes all Nodes in list.
 * O(n)
 *****************************************/
void LinkedList::delete_all() {
    if (start == NULL) {
        cout << "There is no sentence to be deleted." << endl;
        return;
    } else {
        Node * current = start;
        while (current != NULL) {
            start = start->next;
            free(current);
            current = start;
        }
    }
}

/******************************************
 * Method: display()
 * Description: Display all Nodes in list.
 * O(n)
 *****************************************/
void LinkedList::display() {
    if (start == NULL) {
        cout << "There is currently no sentence created to display." << endl;
        return;
    } else {
        Node * current = start;
        while (current != NULL) {
            cout << current->data;
            current = current->next;
        }
    }
    cout << endl;
}

/******************************************
 * Method: string()
 * Description: Returns a string of the 
 * Linked List node->data
 * O(n)
 *****************************************/
string LinkedList::toString() {
    char sentence[1000];
    if (start == NULL) {
        cout << "There is currently no sentence created to display." << endl;
        string s(sentence);
        return s;
    } else {
        
        int i = 0;
        Node * current = start;
        while (current != NULL) {
            sentence[i] = current->data;
            i++;
            current = current->next;
        }
    }
    string s(sentence);
    return s;
}

/******************************************
 * Method: size()
 * Description: Returns Size of Linked List
 * O(n)
 *****************************************/
int LinkedList::size() {
    int count = 0;
    
    if (start == NULL) {
        cout << "There is no sentence to check the size of." << endl;
    } else if (start->next == NULL) {
        cout << "There is only one letter in the sentence." << endl;
        count++;
    } else {
        Node * current = start;
        while (current != NULL) {
            count++;
            current = current->next;
        }
    }
    return count;
}
 
/******************************************
 * Method: check_sentence()
 * Description: Checks if a sentence currently
 * exists and returns true or false
 * O(1)
 *****************************************/
 bool LinkedList::check_sentence() {
    if (start == NULL) {
        return false;
    } else {
        return true;
    }
 }
 
/******************************************
 * Method: sort_sentence()
 * Description: Sorts all nodes alphabetically
 * in ascending order A-Z,a-z
 * O(n^2) - Selection Sort
 *******************************************/
void LinkedList::sort_sentence() {
    if (start == NULL) {
        cout << "Their is currently no sentence to sort" << endl;
        return;
    } else if (start->next == NULL) {
        cout << "Their is only 1 letter in the sentence" << endl;
        return;
    } else {
        Node * current = start;
        Node * smallest = start;
        Node * iterator = start;
        char temp;
       
        cout << "The message was: ";
        this->display();
        
        while (current != NULL) {
            iterator = current;
            smallest = iterator;
            while (iterator != NULL) {
                if ( (int)iterator->data < (int)smallest->data ) {
                    smallest = iterator;   
                }
                iterator = iterator->next;
            }
            // Sort the smallest into correct position   
            temp = current->data;
            current->data = smallest->data;
            smallest->data = temp;
            
            current = current->next;
        }   
    }
    cout << "The message is now: ";
    this->display();
}

#endif /* LINKEDLIST_H */