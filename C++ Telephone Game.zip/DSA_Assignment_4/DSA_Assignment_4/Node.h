/*******************************************************************
 * Program: Assignment 4
 * Programmer: Jayce Merinchuk
 * Programmer: Vanessa Li
 * Programmer: Haya ElGhalayini
 * Date: March 14, 2019
 * File: Node.h
 * Description: Data Structure for a Node to be used in Linked List.
 * 
 * Sources: 
 *  Haya's previous in class examples on Linked Lists provided this code.
 ******************************************************************/

#ifndef NODE_H
#define NODE_H

/*********************************************
 * Method: struct Node
 * Description: Contains character for data
 * and pointer to the next Node
 ********************************************/
struct Node {
    char data;
    Node* next;
};

#endif /* NODE_H */